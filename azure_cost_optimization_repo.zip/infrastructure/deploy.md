# Infrastructure Deployment

### Create Storage Account and Container
```bash
az storage account create --name billingarchivestorage --resource-group <RG_NAME> --location <LOCATION> --sku Standard_LRS
az storage container create --account-name billingarchivestorage --name cold-billing-records
```

### Cosmos DB Setup
```bash
az cosmosdb create --name <COSMOS_ACCOUNT> --resource-group <RG_NAME> --kind GlobalDocumentDB
az cosmosdb sql database create --account-name <COSMOS_ACCOUNT> --name <DB_NAME> --resource-group <RG_NAME>
```

### Deploy Azure Function
```bash
func azure functionapp publish <FunctionAppName>
```
