# Azure Billing Records Cost Optimization

## Overview
This project provides a cost optimization strategy for managing billing records in Azure Cosmos DB using a serverless architecture. 
Old records (older than 3 months) are archived into Azure Blob Storage to reduce costs while maintaining availability.

## Architecture
![Architecture](docs/architecture.png)

### Components
- **Azure Cosmos DB** for hot data (last 3 months).
- **Azure Blob Storage** for cold data.
- **Azure Functions** for automated archival and retrieval.
- **Billing API** abstracts data retrieval (Cosmos first, then Blob).

## Key Features
- No API contract changes.
- Zero downtime migration.
- Cost reduction via tiered storage.

## Folder Structure
- `functions/` - Archival Azure Function (Python).
- `api/` - Billing API data access abstraction.
- `infrastructure/` - Azure CLI/ARM templates.
- `docs/` - Documentation and diagrams.

## Deployment
See [infrastructure/deploy.md](infrastructure/deploy.md).

