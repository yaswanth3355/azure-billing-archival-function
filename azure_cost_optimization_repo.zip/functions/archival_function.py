import azure.cosmos.cosmos_client as cosmos_client
from azure.storage.blob import BlobServiceClient
import json
import datetime
import os

COSMOS_URI = os.environ.get("COSMOS_URI")
COSMOS_KEY = os.environ.get("COSMOS_KEY")
DB_NAME = os.environ.get("COSMOS_DB_NAME")
COLLECTION_NAME = os.environ.get("COSMOS_COLLECTION")
BLOB_CONN_STRING = os.environ.get("BLOB_CONN_STRING")

def main(mytimer):
    cutoff_date = datetime.datetime.utcnow() - datetime.timedelta(days=90)
    
    cosmos = cosmos_client.CosmosClient(COSMOS_URI, {'masterKey': COSMOS_KEY})
    container = cosmos.get_database_client(DB_NAME).get_container_client(COLLECTION_NAME)
    
    query = f"SELECT * FROM c WHERE c.timestamp < '{cutoff_date.isoformat()}'"
    records = list(container.query_items(query=query, enable_cross_partition_query=True))
    
    blob_service_client = BlobServiceClient.from_connection_string(BLOB_CONN_STRING)
    container_client = blob_service_client.get_container_client("cold-billing-records")
    
    for record in records:
        record_id = record['id']
        archive_path = f"{record['timestamp'][:7]}/{record_id}.json"
        container_client.upload_blob(name=archive_path, data=json.dumps(record), overwrite=True)
        container.delete_item(item=record_id, partition_key=record['partitionKey'])
