import json
from azure.storage.blob import BlobServiceClient
import azure.cosmos.cosmos_client as cosmos_client
import os

COSMOS_URI = os.environ.get("COSMOS_URI")
COSMOS_KEY = os.environ.get("COSMOS_KEY")
DB_NAME = os.environ.get("COSMOS_DB_NAME")
COLLECTION_NAME = os.environ.get("COSMOS_COLLECTION")
BLOB_CONN_STRING = os.environ.get("BLOB_CONN_STRING")

cosmos = cosmos_client.CosmosClient(COSMOS_URI, {'masterKey': COSMOS_KEY})
container = cosmos.get_database_client(DB_NAME).get_container_client(COLLECTION_NAME)
blob_service_client = BlobServiceClient.from_connection_string(BLOB_CONN_STRING)

def get_billing_record(record_id):
    try:
        return container.read_item(item=record_id, partition_key=record_id)
    except:
        blob_name = find_blob_path(record_id)
        blob_client = blob_service_client.get_blob_client(container="cold-billing-records", blob=blob_name)
        blob_data = blob_client.download_blob().readall()
        return json.loads(blob_data)

def find_blob_path(record_id):
    # Custom logic to map record_id to blob path
    # For demo, assume record_id includes date: YYYY-MM-<id>
    return f"{record_id[:7]}/{record_id}.json"
